export { useCalendarHighlight } from './useCalendarHighlight'
export { default as highlightStyles } from './_styles.module.scss'

