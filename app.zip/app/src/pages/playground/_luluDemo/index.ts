import Demo_ColorChart_V0 from './Demo_ColorChart_V0';
import SalesEventCalendar_V1 from './SalesEventCalendar_V1';
import TrendChartDemo_V1 from './TrendChartDemo_V1';
import JingjingOnePage_V0 from './JingjingOnePage_V0';
import HellenSalesEventTrend_V1 from './HellenSalesEventTrend_V1';

export const LuluDemoPages = {
  Demo_ColorChart_V0,
  SalesEventCalendar_V1,
  TrendChartDemo_V1,
  HellenSalesEventTrend_V1,
  JingjingOnePage_V0,
}