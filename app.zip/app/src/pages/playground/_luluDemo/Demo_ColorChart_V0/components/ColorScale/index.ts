export { ColorScale } from './_component'
export { ColorScale as default } from './_component'
export type { ColorScaleProps } from './_component'

