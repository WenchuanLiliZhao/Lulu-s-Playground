export { ColorScaleItem } from './_component'
export { ColorScaleItem as default } from './_component'
export type { ColorScaleItemProps } from './_component'

