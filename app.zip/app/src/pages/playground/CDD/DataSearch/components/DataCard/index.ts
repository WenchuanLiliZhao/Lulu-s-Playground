export { DataCard } from './_component'
export { DataCard as default } from './_component'
export type { DataCardProps } from './_component'

