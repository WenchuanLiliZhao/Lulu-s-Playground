export { RichText } from './_component';
export { RichText as default } from './_component';
export type { RichTextProps, RichTextContent } from './_component';

