export { StatusBadge } from './_component';
export { StatusBadge as default } from './_component';
export type { StatusBadgeProps } from './_component';

