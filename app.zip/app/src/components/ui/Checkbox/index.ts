export { Checkbox } from './_component'
export { Checkbox as default } from './_component'
export type { CheckboxProps } from './_component'

