export { Icon } from './_component'
export { Icon as default } from './_component'
export type { IconProps } from './_component'
