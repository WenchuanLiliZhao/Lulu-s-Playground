export { WeatherWidget } from './_component';
export { WeatherWidget as default } from './_component';
export type { WeatherWidgetProps } from './_component';

