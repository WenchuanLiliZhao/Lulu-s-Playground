export { ChatDialog } from './_component'
export { ChatDialog as default } from './_component'
export type { ChatDialogProps } from './_component'

