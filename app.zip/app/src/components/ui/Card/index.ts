export { Card } from './_component';
export { Card as default } from './_component';
export type { CardProps } from './_component';

