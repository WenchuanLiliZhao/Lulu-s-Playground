export { FloatingActionButton } from "./_component";
export { FloatingActionButton as default } from "./_component";
export type { FloatingActionButtonProps } from "./_component";

