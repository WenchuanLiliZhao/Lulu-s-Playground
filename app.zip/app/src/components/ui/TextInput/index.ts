export { TextInput } from './_component'
export { TextInput as default } from './_component'
export type { TextInputProps } from './_component'

