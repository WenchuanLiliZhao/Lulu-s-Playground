export { TextWidget } from './_component'
export { TextWidget as default } from './_component'
export type { TextWidgetProps } from './_component'

