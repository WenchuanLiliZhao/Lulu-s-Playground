export { SwitchableDataWidget } from './_component'
export type { SwitchableDataWidgetProps, DataWidgetViewMode } from './_component'
export { SwitchableDataWidget as default } from './_component'

