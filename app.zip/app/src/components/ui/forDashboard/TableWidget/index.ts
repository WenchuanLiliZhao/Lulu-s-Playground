export { TableWidget } from './_component'
export { TableWidget as default } from './_component'
export type { TableWidgetProps } from './_component'

