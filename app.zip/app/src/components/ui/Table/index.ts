export { Table } from './_component'
export { Table as default } from './_component'
export type { TableProps, TableColumn } from './_component'

