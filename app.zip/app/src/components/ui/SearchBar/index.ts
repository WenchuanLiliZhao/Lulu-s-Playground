export { SearchBar } from './_component'
export { SearchBar as default } from './_component'
export type { SearchBarProps } from './_component'

