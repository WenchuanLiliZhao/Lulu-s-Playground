export { Popup } from './_component'
export { Popup as default } from './_component'
export type { PopupProps, PopupPlacement } from './_component'


