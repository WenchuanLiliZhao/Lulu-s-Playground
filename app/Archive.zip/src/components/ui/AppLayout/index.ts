export { AppLayout } from './_component'
export { AppLayout as default } from './_component'
export type { AppLayoutProps } from './_component'

// Export feature types for external use
export type { ViewportMode } from './features'

