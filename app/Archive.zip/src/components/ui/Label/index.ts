export { Label } from './_component'
export { Label as default } from './_component'
export type { LabelProps } from './_component'

