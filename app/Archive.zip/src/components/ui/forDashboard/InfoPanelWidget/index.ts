export { InfoPanelWidget } from './_component';
export type { InfoPanelWidgetProps, InfoItem } from './_component';

