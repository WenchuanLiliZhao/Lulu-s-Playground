export { PathwayVisualization3D } from './_component'
export { PathwayVisualization3D as default } from './_component'
export { PATHWAY_VISUALIZATION_DEFAULTS } from './_config'
export type { 
  PathwayVisualization3DProps,
  PathNode,
  PathConnection,
} from './_component'

