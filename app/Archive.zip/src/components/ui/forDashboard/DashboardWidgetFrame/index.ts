export { DashboardWidgetFrame } from './_component'
export { DashboardWidgetFrame as default } from './_component'
export type { DashboardWidgetFrameProps } from './_component'

