export { IconButton } from './_component'
export { IconButton as default } from './_component'
export type { IconButtonProps } from './_component'

