export { Switch } from './_component'
export { Switch as default } from './_component'
export type { SwitchProps, SwitchOption } from './_component'

