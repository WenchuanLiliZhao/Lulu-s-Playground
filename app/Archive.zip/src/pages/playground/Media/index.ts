import YouTubeAudioFetchPage from "./YouTubeAudioFetch";

export const MediaPages = {
  YouTubeAudioFetchPage,
};

