export { EventLabel } from './_component'
export { EventLabel as default } from './_component'
export type { EventLabelProps } from './_component'

