export { OriginalBadge } from './_component'
export { OriginalBadge as default } from './_component'
export type { OriginalBadgeProps } from './_component'

