import DataSearchPage from './DataSearch';

export * from './DataSearch';

export const CDDPages = {
  DataSearchPage,
}