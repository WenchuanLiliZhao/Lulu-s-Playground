export { Tag } from './_component'
export { Tag as default } from './_component'
export type { TagProps } from './_component'

