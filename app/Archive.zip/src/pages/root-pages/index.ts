import Home from "./home";
import NotFound from "./not-found";

export const RootPages = {
  Home,
  NotFound,
}