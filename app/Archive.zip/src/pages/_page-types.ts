export interface PageProps {
  title: string;
  slug: string;
  content: React.ReactNode;
}